import uuid, os, sys

def uid():
    return uuid.uuid4().hex[:24].upper()

# Ensure global uniqueness across the whole run
_used = set()
def new_uid():
    while True:
        u = uid()
        if u not in _used:
            _used.add(u)
            return u

groups_def = {
    "Crypto": ["DoubleRatchet.swift", "Identity.swift", "X3DH.swift", "RatchetPrimitives.swift", "CallSession.swift"],
    "Models": ["ChatMessage.swift", "Contact.swift", "CallModels.swift"],
    "Networking": ["MeshTransport.swift", "MessageRouter.swift", "SOCKS5Client.swift", "TorTransport.swift"],
    "Audio": ["CallAudioEngine.swift"],
    "ViewModel": ["AppViewModel.swift", "CallViewModel.swift"],
    "Views": ["ChatView.swift", "ContentView.swift", "PairingView.swift", "SettingsView.swift", "CallView.swift"],
}
top_level_files = ["GhostMeshApp.swift"]

# ids
root_group = new_uid()
products_group = new_uid()
app_root_group = new_uid()
proj_obj = new_uid()
target_id = new_uid()
product_ref = new_uid()
frameworks_phase = new_uid()
sources_phase = new_uid()
resources_phase = new_uid()
build_cfg_list_proj = new_uid()
build_cfg_debug_proj = new_uid()
build_cfg_release_proj = new_uid()
build_cfg_list_target = new_uid()
build_cfg_debug_target = new_uid()
build_cfg_release_target = new_uid()
pkg_ref = new_uid()
pkg_product_dep = new_uid()
pkg_buildfile = new_uid()
assets_fileref = new_uid()
assets_buildfile = new_uid()
preview_assets_fileref = new_uid()
preview_assets_buildfile = new_uid()
infoplist_fileref = new_uid()
preview_content_group = new_uid()

file_entries = []  # (fileref_id, buildfile_id, name, group_name)
group_ids = {}
for g in groups_def:
    group_ids[g] = new_uid()

for gname, files in groups_def.items():
    for f in files:
        fr = new_uid()
        bf = new_uid()
        file_entries.append((fr, bf, f, gname))

top_entries = []
for f in top_level_files:
    fr = new_uid()
    bf = new_uid()
    top_entries.append((fr, bf, f))

lines = []
lines.append("// !$*UTF8*$!")
lines.append("{")
lines.append("\tarchiveVersion = 1;")
lines.append("\tclasses = {")
lines.append("\t};")
lines.append("\tobjectVersion = 56;")
lines.append("\tobjects = {")
lines.append("")

# PBXBuildFile
lines.append("/* Begin PBXBuildFile section */")
for fr, bf, f, g in file_entries:
    lines.append(f"\t\t{bf} /* {f} in Sources */ = {{isa = PBXBuildFile; fileRef = {fr} /* {f} */; }};")
for fr, bf, f in top_entries:
    lines.append(f"\t\t{bf} /* {f} in Sources */ = {{isa = PBXBuildFile; fileRef = {fr} /* {f} */; }};")
lines.append(f"\t\t{assets_buildfile} /* Assets.xcassets in Resources */ = {{isa = PBXBuildFile; fileRef = {assets_fileref} /* Assets.xcassets */; }};")
lines.append(f"\t\t{preview_assets_buildfile} /* Preview Assets.xcassets in Resources */ = {{isa = PBXBuildFile; fileRef = {preview_assets_fileref} /* Preview Assets.xcassets */; }};")
lines.append(f"\t\t{pkg_buildfile} /* Tor in Frameworks */ = {{isa = PBXBuildFile; productRef = {pkg_product_dep} /* Tor */; }};")
lines.append("/* End PBXBuildFile section */")
lines.append("")

# PBXFileReference
lines.append("/* Begin PBXFileReference section */")
lines.append(f"\t\t{product_ref} /* GhostMesh.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = GhostMesh.app; sourceTree = BUILT_PRODUCTS_DIR; }};")
for fr, bf, f, g in file_entries:
    lines.append(f"\t\t{fr} /* {f} */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {f}; sourceTree = \"<group>\"; }};")
for fr, bf, f in top_entries:
    lines.append(f"\t\t{fr} /* {f} */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {f}; sourceTree = \"<group>\"; }};")
lines.append(f"\t\t{assets_fileref} /* Assets.xcassets */ = {{isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = Assets.xcassets; sourceTree = \"<group>\"; }};")
lines.append(f"\t\t{preview_assets_fileref} /* Preview Assets.xcassets */ = {{isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = \"Preview Assets.xcassets\"; sourceTree = \"<group>\"; }};")
lines.append(f"\t\t{infoplist_fileref} /* Info.plist */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = Info.plist; sourceTree = \"<group>\"; }};")
lines.append("/* End PBXFileReference section */")
lines.append("")

# PBXFrameworksBuildPhase
lines.append("/* Begin PBXFrameworksBuildPhase section */")
lines.append(f"\t\t{frameworks_phase} /* Frameworks */ = {{")
lines.append("\t\t\tisa = PBXFrameworksBuildPhase;")
lines.append("\t\t\tbuildActionMask = 2147483647;")
lines.append("\t\t\tfiles = (")
lines.append(f"\t\t\t\t{pkg_buildfile} /* Tor in Frameworks */,")
lines.append("\t\t\t);")
lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
lines.append("\t\t};")
lines.append("/* End PBXFrameworksBuildPhase section */")
lines.append("")

# PBXGroup
lines.append("/* Begin PBXGroup section */")
lines.append(f"\t\t{root_group} = {{")
lines.append("\t\t\tisa = PBXGroup;")
lines.append("\t\t\tchildren = (")
lines.append(f"\t\t\t\t{app_root_group} /* GhostMesh */,")
lines.append(f"\t\t\t\t{products_group} /* Products */,")
lines.append("\t\t\t);")
lines.append("\t\t\tsourceTree = \"<group>\";")
lines.append("\t\t};")

lines.append(f"\t\t{products_group} /* Products */ = {{")
lines.append("\t\t\tisa = PBXGroup;")
lines.append("\t\t\tchildren = (")
lines.append(f"\t\t\t\t{product_ref} /* GhostMesh.app */,")
lines.append("\t\t\t);")
lines.append("\t\t\tname = Products;")
lines.append("\t\t\tsourceTree = \"<group>\";")
lines.append("\t\t};")

lines.append(f"\t\t{app_root_group} /* GhostMesh */ = {{")
lines.append("\t\t\tisa = PBXGroup;")
lines.append("\t\t\tchildren = (")
for fr, bf, f in top_entries:
    lines.append(f"\t\t\t\t{fr} /* {f} */,")
for gname in groups_def:
    lines.append(f"\t\t\t\t{group_ids[gname]} /* {gname} */,")
lines.append(f"\t\t\t\t{assets_fileref} /* Assets.xcassets */,")
lines.append(f"\t\t\t\t{infoplist_fileref} /* Info.plist */,")
lines.append(f"\t\t\t\t{preview_content_group} /* Preview Content */,")
lines.append("\t\t\t);")
lines.append("\t\t\tpath = GhostMesh;")
lines.append("\t\t\tsourceTree = \"<group>\";")
lines.append("\t\t};")

for gname, files in groups_def.items():
    lines.append(f"\t\t{group_ids[gname]} /* {gname} */ = {{")
    lines.append("\t\t\tisa = PBXGroup;")
    lines.append("\t\t\tchildren = (")
    for fr, bf, f, g in file_entries:
        if g == gname:
            lines.append(f"\t\t\t\t{fr} /* {f} */,")
    lines.append("\t\t\t);")
    lines.append(f"\t\t\tpath = {gname};")
    lines.append("\t\t\tsourceTree = \"<group>\";")
    lines.append("\t\t};")

lines.append(f"\t\t{preview_content_group} /* Preview Content */ = {{")
lines.append("\t\t\tisa = PBXGroup;")
lines.append("\t\t\tchildren = (")
lines.append(f"\t\t\t\t{preview_assets_fileref} /* Preview Assets.xcassets */,")
lines.append("\t\t\t);")
lines.append("\t\t\tpath = \"Preview Content\";")
lines.append("\t\t\tsourceTree = \"<group>\";")
lines.append("\t\t};")
lines.append("/* End PBXGroup section */")
lines.append("")

# PBXNativeTarget
lines.append("/* Begin PBXNativeTarget section */")
lines.append(f"\t\t{target_id} /* GhostMesh */ = {{")
lines.append("\t\t\tisa = PBXNativeTarget;")
lines.append(f"\t\t\tbuildConfigurationList = {build_cfg_list_target} /* Build configuration list for PBXNativeTarget \"GhostMesh\" */;")
lines.append("\t\t\tbuildPhases = (")
lines.append(f"\t\t\t\t{sources_phase} /* Sources */,")
lines.append(f"\t\t\t\t{frameworks_phase} /* Frameworks */,")
lines.append(f"\t\t\t\t{resources_phase} /* Resources */,")
lines.append("\t\t\t);")
lines.append("\t\t\tbuildRules = (")
lines.append("\t\t\t);")
lines.append("\t\t\tdependencies = (")
lines.append("\t\t\t);")
lines.append("\t\t\tname = GhostMesh;")
lines.append("\t\t\tpackageProductDependencies = (")
lines.append(f"\t\t\t\t{pkg_product_dep} /* Tor */,")
lines.append("\t\t\t);")
lines.append("\t\t\tproductName = GhostMesh;")
lines.append(f"\t\t\tproductReference = {product_ref} /* GhostMesh.app */;")
lines.append("\t\t\tproductType = \"com.apple.product-type.application\";")
lines.append("\t\t};")
lines.append("/* End PBXNativeTarget section */")
lines.append("")

# PBXProject
lines.append("/* Begin PBXProject section */")
lines.append(f"\t\t{proj_obj} /* Project object */ = {{")
lines.append("\t\t\tisa = PBXProject;")
lines.append("\t\t\tattributes = {")
lines.append("\t\t\t\tBuildIndependentTargetsInParallel = 1;")
lines.append("\t\t\t\tLastSwiftUpdateCheck = 1600;")
lines.append("\t\t\t\tLastUpgradeCheck = 1600;")
lines.append("\t\t\t\tTargetAttributes = {")
lines.append(f"\t\t\t\t\t{target_id} = {{")
lines.append("\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;")
lines.append("\t\t\t\t\t};")
lines.append("\t\t\t\t};")
lines.append("\t\t\t};")
lines.append(f"\t\t\tbuildConfigurationList = {build_cfg_list_proj} /* Build configuration list for PBXProject \"GhostMesh\" */;")
lines.append("\t\t\tcompatibilityVersion = \"Xcode 14.0\";")
lines.append("\t\t\tdevelopmentRegion = en;")
lines.append("\t\t\thasScannedForEncodings = 0;")
lines.append("\t\t\tknownRegions = (")
lines.append("\t\t\t\ten,")
lines.append("\t\t\t\tBase,")
lines.append("\t\t\t);")
lines.append(f"\t\t\tmainGroup = {root_group};")
lines.append("\t\t\tpackageReferences = (")
lines.append(f"\t\t\t\t{pkg_ref} /* XCRemoteSwiftPackageReference \"swift-tor\" */,")
lines.append("\t\t\t);")
lines.append(f"\t\t\tproductRefGroup = {products_group} /* Products */;")
lines.append("\t\t\tprojectDirPath = \"\";")
lines.append("\t\t\tprojectRoot = \"\";")
lines.append("\t\t\ttargets = (")
lines.append(f"\t\t\t\t{target_id} /* GhostMesh */,")
lines.append("\t\t\t);")
lines.append("\t\t};")
lines.append("/* End PBXProject section */")
lines.append("")

# PBXResourcesBuildPhase
lines.append("/* Begin PBXResourcesBuildPhase section */")
lines.append(f"\t\t{resources_phase} /* Resources */ = {{")
lines.append("\t\t\tisa = PBXResourcesBuildPhase;")
lines.append("\t\t\tbuildActionMask = 2147483647;")
lines.append("\t\t\tfiles = (")
lines.append(f"\t\t\t\t{assets_buildfile} /* Assets.xcassets in Resources */,")
lines.append(f"\t\t\t\t{preview_assets_buildfile} /* Preview Assets.xcassets in Resources */,")
lines.append("\t\t\t);")
lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
lines.append("\t\t};")
lines.append("/* End PBXResourcesBuildPhase section */")
lines.append("")

# PBXSourcesBuildPhase
lines.append("/* Begin PBXSourcesBuildPhase section */")
lines.append(f"\t\t{sources_phase} /* Sources */ = {{")
lines.append("\t\t\tisa = PBXSourcesBuildPhase;")
lines.append("\t\t\tbuildActionMask = 2147483647;")
lines.append("\t\t\tfiles = (")
for fr, bf, f, g in file_entries:
    lines.append(f"\t\t\t\t{bf} /* {f} in Sources */,")
for fr, bf, f in top_entries:
    lines.append(f"\t\t\t\t{bf} /* {f} in Sources */,")
lines.append("\t\t\t);")
lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
lines.append("\t\t};")
lines.append("/* End PBXSourcesBuildPhase section */")
lines.append("")

# XCBuildConfiguration (project level)
common_debug = """
				ALWAYS_SEARCH_USER_PATHS = NO;
				CLANG_ANALYZER_NONNULL = YES;
				CLANG_ANALYZER_NUMBER_OBJECT_CONVERSION = YES_AGGRESSIVE;
				CLANG_CXX_LANGUAGE_STANDARD = "gnu++20";
				CLANG_ENABLE_MODULES = YES;
				CLANG_ENABLE_OBJC_ARC = YES;
				CLANG_ENABLE_OBJC_WEAK = YES;
				CLANG_WARN_BLOCK_CAPTURE_AUTORELEASING = YES;
				CLANG_WARN_BOOL_CONVERSION = YES;
				CLANG_WARN_COMMA = YES;
				CLANG_WARN_CONSTANT_CONVERSION = YES;
				CLANG_WARN_DEPRECATED_OBJC_IMPLEMENTATIONS = YES;
				CLANG_WARN_DIRECT_OBJC_ISA_USAGE = YES_ERROR;
				CLANG_WARN_DOCUMENTATION_COMMENTS = YES;
				CLANG_WARN_EMPTY_BODY = YES;
				CLANG_WARN_ENUM_CONVERSION = YES;
				CLANG_WARN_INFINITE_RECURSION = YES;
				CLANG_WARN_INT_CONVERSION = YES;
				CLANG_WARN_NON_LITERAL_NULL_CONVERSION = YES;
				CLANG_WARN_OBJC_IMPLICIT_RETAIN_SELF = YES;
				CLANG_WARN_OBJC_LITERAL_CONVERSION = YES;
				CLANG_WARN_OBJC_ROOT_CLASS = YES_ERROR;
				CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER = YES;
				CLANG_WARN_RANGE_LOOP_ANALYSIS = YES;
				CLANG_WARN_STRICT_PROTOTYPES = YES;
				CLANG_WARN_SUSPICIOUS_MOVE = YES;
				CLANG_WARN_UNGUARDED_AVAILABILITY = YES_AGGRESSIVE;
				CLANG_WARN_UNREACHABLE_CODE = YES;
				CLANG_WARN__DUPLICATE_METHOD_MATCH = YES;
				COPY_PHASE_STRIP = NO;
				DEBUG_INFORMATION_FORMAT = dwarf;
				ENABLE_STRICT_OBJC_MSGSEND = YES;
				ENABLE_TESTABILITY = YES;
				GCC_C_LANGUAGE_STANDARD = gnu17;
				GCC_DYNAMIC_NO_PIC = NO;
				GCC_NO_COMMON_BLOCKS = YES;
				GCC_OPTIMIZATION_LEVEL = 0;
				GCC_PREPROCESSOR_DEFINITIONS = (
					"DEBUG=1",
					"$(inherited)",
				);
				GCC_WARN_64_TO_32_BIT_CONVERSION = YES;
				GCC_WARN_ABOUT_RETURN_TYPE = YES_ERROR;
				GCC_WARN_UNDECLARED_SELECTOR = YES;
				GCC_WARN_UNINITIALIZED_AUTOS = YES_AGGRESSIVE;
				GCC_WARN_UNUSED_FUNCTION = YES;
				GCC_WARN_UNUSED_VARIABLE = YES;
				IPHONEOS_DEPLOYMENT_TARGET = 18.0;
				MTL_ENABLE_DEBUG_INFO = INCLUDE_SOURCE;
				MTL_FAST_MATH = YES;
				ONLY_ACTIVE_ARCH = YES;
				SDKROOT = iphoneos;
				SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG;
				SWIFT_OPTIMIZATION_LEVEL = "-Onone";
				SWIFT_VERSION = 6.0;
""".strip("\n")

common_release = """
				ALWAYS_SEARCH_USER_PATHS = NO;
				CLANG_ANALYZER_NONNULL = YES;
				CLANG_ANALYZER_NUMBER_OBJECT_CONVERSION = YES_AGGRESSIVE;
				CLANG_CXX_LANGUAGE_STANDARD = "gnu++20";
				CLANG_ENABLE_MODULES = YES;
				CLANG_ENABLE_OBJC_ARC = YES;
				CLANG_ENABLE_OBJC_WEAK = YES;
				CLANG_WARN_BLOCK_CAPTURE_AUTORELEASING = YES;
				CLANG_WARN_BOOL_CONVERSION = YES;
				CLANG_WARN_COMMA = YES;
				CLANG_WARN_CONSTANT_CONVERSION = YES;
				CLANG_WARN_DEPRECATED_OBJC_IMPLEMENTATIONS = YES;
				CLANG_WARN_DIRECT_OBJC_ISA_USAGE = YES_ERROR;
				CLANG_WARN_DOCUMENTATION_COMMENTS = YES;
				CLANG_WARN_EMPTY_BODY = YES;
				CLANG_WARN_ENUM_CONVERSION = YES;
				CLANG_WARN_INFINITE_RECURSION = YES;
				CLANG_WARN_INT_CONVERSION = YES;
				CLANG_WARN_NON_LITERAL_NULL_CONVERSION = YES;
				CLANG_WARN_OBJC_IMPLICIT_RETAIN_SELF = YES;
				CLANG_WARN_OBJC_LITERAL_CONVERSION = YES;
				CLANG_WARN_OBJC_ROOT_CLASS = YES_ERROR;
				CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER = YES;
				CLANG_WARN_RANGE_LOOP_ANALYSIS = YES;
				CLANG_WARN_STRICT_PROTOTYPES = YES;
				CLANG_WARN_SUSPICIOUS_MOVE = YES;
				CLANG_WARN_UNGUARDED_AVAILABILITY = YES_AGGRESSIVE;
				CLANG_WARN_UNREACHABLE_CODE = YES;
				CLANG_WARN__DUPLICATE_METHOD_MATCH = YES;
				COPY_PHASE_STRIP = NO;
				DEBUG_INFORMATION_FORMAT = "dwarf-with-dsym";
				ENABLE_NS_ASSERTIONS = NO;
				ENABLE_STRICT_OBJC_MSGSEND = YES;
				GCC_C_LANGUAGE_STANDARD = gnu17;
				GCC_NO_COMMON_BLOCKS = YES;
				GCC_WARN_64_TO_32_BIT_CONVERSION = YES;
				GCC_WARN_ABOUT_RETURN_TYPE = YES_ERROR;
				GCC_WARN_UNDECLARED_SELECTOR = YES;
				GCC_WARN_UNINITIALIZED_AUTOS = YES_AGGRESSIVE;
				GCC_WARN_UNUSED_FUNCTION = YES;
				GCC_WARN_UNUSED_VARIABLE = YES;
				IPHONEOS_DEPLOYMENT_TARGET = 18.0;
				MTL_ENABLE_DEBUG_INFO = NO;
				MTL_FAST_MATH = YES;
				SDKROOT = iphoneos;
				SWIFT_COMPILATION_MODE = wholemodule;
				SWIFT_OPTIMIZATION_LEVEL = "-O";
				SWIFT_VERSION = 6.0;
				VALIDATE_PRODUCT = YES;
""".strip("\n")

target_common = """
				ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
				ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME = AccentColor;
				CODE_SIGN_STYLE = Automatic;
				CURRENT_PROJECT_VERSION = 1;
				DEVELOPMENT_ASSET_PATHS = "\\"GhostMesh/Preview Content\\"";
				ENABLE_PREVIEWS = YES;
				GENERATE_INFOPLIST_FILE = YES;
				INFOPLIST_FILE = GhostMesh/Info.plist;
				INFOPLIST_KEY_UILaunchScreen_Generation = YES;
				INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES;
				INFOPLIST_KEY_UISupportedInterfaceOrientations = UIInterfaceOrientationPortrait;
				LD_RUNPATH_SEARCH_PATHS = (
					"$(inherited)",
					"@executable_path/Frameworks",
				);
				MARKETING_VERSION = 1.0;
				PRODUCT_BUNDLE_IDENTIFIER = com.lbl215.ghostmesh;
				PRODUCT_NAME = GhostMesh;
				SWIFT_EMIT_LOC_STRINGS = YES;
				SWIFT_VERSION = 6.0;
				TARGETED_DEVICE_FAMILY = "1,2";
""".strip("\n")

lines.append("/* Begin XCBuildConfiguration section */")
lines.append(f"\t\t{build_cfg_debug_proj} /* Debug */ = {{")
lines.append("\t\t\tisa = XCBuildConfiguration;")
lines.append("\t\t\tbuildSettings = {")
lines.append(common_debug)
lines.append("\t\t\t};")
lines.append("\t\t\tname = Debug;")
lines.append("\t\t};")

lines.append(f"\t\t{build_cfg_release_proj} /* Release */ = {{")
lines.append("\t\t\tisa = XCBuildConfiguration;")
lines.append("\t\t\tbuildSettings = {")
lines.append(common_release)
lines.append("\t\t\t};")
lines.append("\t\t\tname = Release;")
lines.append("\t\t};")

lines.append(f"\t\t{build_cfg_debug_target} /* Debug */ = {{")
lines.append("\t\t\tisa = XCBuildConfiguration;")
lines.append("\t\t\tbuildSettings = {")
lines.append(target_common)
lines.append("\t\t\t};")
lines.append("\t\t\tname = Debug;")
lines.append("\t\t};")

lines.append(f"\t\t{build_cfg_release_target} /* Release */ = {{")
lines.append("\t\t\tisa = XCBuildConfiguration;")
lines.append("\t\t\tbuildSettings = {")
lines.append(target_common)
lines.append("\t\t\t};")
lines.append("\t\t\tname = Release;")
lines.append("\t\t};")
lines.append("/* End XCBuildConfiguration section */")
lines.append("")

lines.append("/* Begin XCConfigurationList section */")
lines.append(f"\t\t{build_cfg_list_proj} /* Build configuration list for PBXProject \"GhostMesh\" */ = {{")
lines.append("\t\t\tisa = XCConfigurationList;")
lines.append("\t\t\tbuildConfigurations = (")
lines.append(f"\t\t\t\t{build_cfg_debug_proj} /* Debug */,")
lines.append(f"\t\t\t\t{build_cfg_release_proj} /* Release */,")
lines.append("\t\t\t);")
lines.append("\t\t\tdefaultConfigurationIsVisible = 0;")
lines.append("\t\t\tdefaultConfigurationName = Release;")
lines.append("\t\t};")
lines.append(f"\t\t{build_cfg_list_target} /* Build configuration list for PBXNativeTarget \"GhostMesh\" */ = {{")
lines.append("\t\t\tisa = XCConfigurationList;")
lines.append("\t\t\tbuildConfigurations = (")
lines.append(f"\t\t\t\t{build_cfg_debug_target} /* Debug */,")
lines.append(f"\t\t\t\t{build_cfg_release_target} /* Release */,")
lines.append("\t\t\t);")
lines.append("\t\t\tdefaultConfigurationIsVisible = 0;")
lines.append("\t\t\tdefaultConfigurationName = Release;")
lines.append("\t\t};")
lines.append("/* End XCConfigurationList section */")
lines.append("")

lines.append("/* Begin XCRemoteSwiftPackageReference section */")
lines.append(f"\t\t{pkg_ref} /* XCRemoteSwiftPackageReference \"swift-tor\" */ = {{")
lines.append("\t\t\tisa = XCRemoteSwiftPackageReference;")
lines.append("\t\t\trepositoryURL = \"https://github.com/21-DOT-DEV/swift-tor\";")
lines.append("\t\t\trequirement = {")
lines.append("\t\t\t\tkind = upToNextMajorVersion;")
lines.append("\t\t\t\tminimumVersion = 0.1.0;")
lines.append("\t\t\t};")
lines.append("\t\t};")
lines.append("/* End XCRemoteSwiftPackageReference section */")
lines.append("")

lines.append("/* Begin XCSwiftPackageProductDependency section */")
lines.append(f"\t\t{pkg_product_dep} /* Tor */ = {{")
lines.append("\t\t\tisa = XCSwiftPackageProductDependency;")
lines.append(f"\t\t\tpackage = {pkg_ref} /* XCRemoteSwiftPackageReference \"swift-tor\" */;")
lines.append("\t\t\tproductName = Tor;")
lines.append("\t\t};")
lines.append("/* End XCSwiftPackageProductDependency section */")

lines.append("\t};")
lines.append(f"\trootObject = {proj_obj} /* Project object */;")
lines.append("}")

output = "\n".join(lines) + "\n"

# --- sanity check: no duplicate object-defining IDs ---
import re
ids = re.findall(r'([A-F0-9]{24}) /\* [^*]+ \*/ = \{isa', output)
from collections import Counter
c = Counter(ids)
dupes = {k: v for k, v in c.items() if v > 1}
if dupes:
    print("DUPLICATE OBJECT IDS FOUND:", dupes)
    sys.exit(1)
print(f"OK: {len(ids)} unique objects, no duplicates.")

out_path = "GhostMesh.xcodeproj/project.pbxproj"
with open(out_path, "w") as fh:
    fh.write(output)
print("wrote", out_path, len(output), "bytes")

# also emit the scheme, filling in the real target UUID
scheme = f"""<?xml version="1.0" encoding="UTF-8"?>
<Scheme
   LastUpgradeVersion = "1600"
   version = "1.7">
   <BuildAction
      parallelizeBuildables = "YES"
      buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry
            buildForTesting = "YES"
            buildForRunning = "YES"
            buildForProfiling = "YES"
            buildForArchiving = "YES"
            buildForAnalyzing = "YES">
            <BuildableReference
               BuildableIdentifier = "primary"
               BlueprintIdentifier = "{target_id}"
               BuildableName = "GhostMesh.app"
               BlueprintName = "GhostMesh"
               ReferencedContainer = "container:GhostMesh.xcodeproj">
            </BuildableReference>
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      shouldUseLaunchSchemeArgsEnv = "YES">
      <Testables>
      </Testables>
   </TestAction>
   <LaunchAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      launchStyle = "0"
      useCustomWorkingDirectory = "NO"
      ignoresPersistentStateOnLaunch = "NO"
      debugDocumentVersioning = "YES"
      debugServiceExtension = "internal"
      allowLocationSimulation = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{target_id}"
            BuildableName = "GhostMesh.app"
            BlueprintName = "GhostMesh"
            ReferencedContainer = "container:GhostMesh.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction
      buildConfiguration = "Release"
      shouldUseLaunchSchemeArgsEnv = "YES"
      savedToolIdentifier = ""
      useCustomWorkingDirectory = "NO"
      debugDocumentVersioning = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{target_id}"
            BuildableName = "GhostMesh.app"
            BlueprintName = "GhostMesh"
            ReferencedContainer = "container:GhostMesh.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction
      buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction
      buildConfiguration = "Release"
      revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
"""
os.makedirs("GhostMesh.xcodeproj/xcshareddata/xcschemes", exist_ok=True)
with open("GhostMesh.xcodeproj/xcshareddata/xcschemes/GhostMesh.xcscheme", "w") as fh:
    fh.write(scheme)
print("wrote scheme")
